package org.cis120.twentyfortyeight;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * You can use this file (and others) to test your
 * implementation.
 */

public class GameTest {

    @Test
    public void testSimpleLeft() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(2, 0, 1);
        t.left();
        int expected = 4;
        int actual = t.getCell(0, 0);
        int score = t.getScore();
        assertEquals(expected, actual);
        assertEquals(expected, score);
    }

    @Test
    public void testLeftWithEmptySpaceInBetween() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(2, 0, 2);
        t.left();
        int expected = 4;
        int actual = t.getCell(0, 0);
        assertEquals(expected, actual);
    }

    @Test
    public void testLeftWithDifferentTileInBetween() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(4, 0, 1);
        t.put(2, 0, 2);
        t.left();
        int expectedFirst = 2;
        int expectedSecond = 4;
        int expectedThird = 2;
        int actualFirst = t.getCell(0, 0);
        int actualSecond = t.getCell(1, 0);
        int actualThird = t.getCell(2, 0);
        assertEquals(expectedFirst, actualFirst);
        assertEquals(expectedSecond, actualSecond);
        assertEquals(expectedThird, actualThird);
    }

    @Test
    public void testLeftWithAllSame() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(2, 0, 1);
        t.put(2, 0, 2);
        t.put(2, 0, 3);
        t.left();
        int expected = 4;
        int actualFirst = t.getCell(0, 0);
        int actualSecond = t.getCell(1, 0);
        assertEquals(expected, actualFirst);
        assertEquals(expected, actualSecond);
    }

    @Test
    public void testLeftWithEmptyFirst() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 1);
        t.put(2, 0, 3);
        t.left();
        int expected = 4;
        int actual = t.getCell(0, 0);
        assertEquals(expected, actual);
    }

    @Test
    public void testLeftButCannotActuallyMove() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(4, 0, 1);
        t.put(8, 0, 2);
        t.put(16, 0, 3);
        t.left();
        int expectedFirst = 2;
        int expectedSecond = 4;
        int expectedThird = 8;
        int expectedFourth = 16;
        assertEquals(expectedFirst, t.getCell(0, 0));
        assertEquals(expectedSecond, t.getCell(1, 0));
        assertEquals(expectedThird, t.getCell(2, 0));
        assertEquals(expectedFourth, t.getCell(3, 0));
    }

    @Test
    public void testSimpleRight() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 2);
        t.put(2, 0, 3);
        t.right();
        int expected = 4;
        int actual = t.getCell(3, 0);
        int score = t.getScore();
        assertEquals(expected, actual);
        assertEquals(expected, score);
    }

    @Test
    public void testRightWithEmptySpaceInBetween() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 3);
        t.put(2, 0, 1);
        t.right();
        int expected = 4;
        int actual = t.getCell(3, 0);
        assertEquals(expected, actual);
    }

    @Test
    public void testRightWithDifferentTileInBetween() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 3);
        t.put(4, 0, 2);
        t.put(2, 0, 1);
        t.right();
        int expectedFirst = 2;
        int expectedSecond = 4;
        int expectedThird = 2;
        int actualFirst = t.getCell(3, 0);
        int actualSecond = t.getCell(2, 0);
        int actualThird = t.getCell(1, 0);
        assertEquals(expectedFirst, actualFirst);
        assertEquals(expectedSecond, actualSecond);
        assertEquals(expectedThird, actualThird);
    }

    @Test
    public void testRightWithAllSame() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(2, 0, 1);
        t.put(2, 0, 2);
        t.put(2, 0, 3);
        t.right();
        int expected = 4;
        int actualFirst = t.getCell(3, 0);
        int actualSecond = t.getCell(2, 0);
        assertEquals(expected, actualFirst);
        assertEquals(expected, actualSecond);
    }

    @Test
    public void testRightWithEmptyFirst() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 2);
        t.put(2, 0, 1);
        t.right();
        int expected = 4;
        int actual = t.getCell(3, 0);
        assertEquals(expected, actual);
    }

    @Test
    public void testRightButCannotActuallyMove() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(4, 0, 1);
        t.put(8, 0, 2);
        t.put(16, 0, 3);
        t.right();
        int expectedFirst = 2;
        int expectedSecond = 4;
        int expectedThird = 8;
        int expectedFourth = 16;
        assertEquals(expectedFirst, t.getCell(0, 0));
        assertEquals(expectedSecond, t.getCell(1, 0));
        assertEquals(expectedThird, t.getCell(2, 0));
        assertEquals(expectedFourth, t.getCell(3, 0));
    }

    @Test
    public void testSimpleUp() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(2, 1, 0);
        t.up();
        int expected = 4;
        int actual = t.getCell(0, 0);
        int score = t.getScore();
        assertEquals(expected, actual);
        assertEquals(expected, score);
    }

    @Test
    public void testUpWithEmptySpaceInBetween() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(2, 2, 0);
        t.up();
        int expected = 4;
        int actual = t.getCell(0, 0);
        assertEquals(expected, actual);
    }

    @Test
    public void testUpWithDifferentTileInBetween() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(4, 1, 0);
        t.put(2, 2, 0);
        t.up();
        int expectedFirst = 2;
        int expectedSecond = 4;
        int expectedThird = 2;
        int actualFirst = t.getCell(0, 0);
        int actualSecond = t.getCell(0, 1);
        int actualThird = t.getCell(0, 2);
        assertEquals(expectedFirst, actualFirst);
        assertEquals(expectedSecond, actualSecond);
        assertEquals(expectedThird, actualThird);
    }

    @Test
    public void testUpWithAllSame() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(2, 1, 0);
        t.put(2, 2, 0);
        t.put(2, 3, 0);
        t.up();
        int expected = 4;
        int actualFirst = t.getCell(0, 0);
        int actualSecond = t.getCell(0, 1);
        assertEquals(expected, actualFirst);
        assertEquals(expected, actualSecond);
    }

    @Test
    public void testUpWithEmptyFirst() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 1, 0);
        t.put(2, 3, 0);
        t.up();
        int expected = 4;
        int actual = t.getCell(0, 0);
        assertEquals(expected, actual);
    }

    @Test
    public void testUpButCannotActuallyMove() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(4, 1, 0);
        t.put(8, 2, 0);
        t.put(16, 3, 0);
        t.left();
        int expectedFirst = 2;
        int expectedSecond = 4;
        int expectedThird = 8;
        int expectedFourth = 16;
        assertEquals(expectedFirst, t.getCell(0, 0));
        assertEquals(expectedSecond, t.getCell(0, 1));
        assertEquals(expectedThird, t.getCell(0, 2));
        assertEquals(expectedFourth, t.getCell(0, 3));
    }

    @Test
    public void testSimpleDown() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 3, 0);
        t.put(2, 2, 0);
        t.down();
        int expected = 4;
        int actual = t.getCell(0, 3);
        int score = t.getScore();
        assertEquals(expected, actual);
        assertEquals(expected, score);
    }

    @Test
    public void testDownWithEmptySpaceInBetween() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(2, 2, 0);
        t.down();
        int expected = 4;
        int actual = t.getCell(0, 3);
        assertEquals(expected, actual);
    }

    @Test
    public void testDownWithDifferentTileInBetween() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 1, 0);
        t.put(4, 2, 0);
        t.put(2, 3, 0);
        t.down();
        int expectedFirst = 2;
        int expectedSecond = 4;
        int expectedThird = 2;
        int actualFirst = t.getCell(0, 1);
        int actualSecond = t.getCell(0, 2);
        int actualThird = t.getCell(0, 3);
        assertEquals(expectedFirst, actualFirst);
        assertEquals(expectedSecond, actualSecond);
        assertEquals(expectedThird, actualThird);
    }

    @Test
    public void testDownWithAllSame() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(2, 1, 0);
        t.put(2, 2, 0);
        t.put(2, 3, 0);
        t.down();
        int expected = 4;
        int actualFirst = t.getCell(0, 3);
        int actualSecond = t.getCell(0, 2);
        assertEquals(expected, actualFirst);
        assertEquals(expected, actualSecond);
    }

    @Test
    public void testDownWithEmptyFirst() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 1, 0);
        t.put(2, 2, 0);
        t.down();
        int expected = 4;
        int actual = t.getCell(0, 3);
        assertEquals(expected, actual);
    }

    @Test
    public void testDownButCannotActuallyMove() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(4, 1, 0);
        t.put(8, 2, 0);
        t.put(16, 3, 0);
        t.down();
        int expectedFirst = 2;
        int expectedSecond = 4;
        int expectedThird = 8;
        int expectedFourth = 16;
        assertEquals(expectedFirst, t.getCell(0, 0));
        assertEquals(expectedSecond, t.getCell(0, 1));
        assertEquals(expectedThird, t.getCell(0, 2));
        assertEquals(expectedFourth, t.getCell(0, 3));
    }

    @Test
    public void testGameOver() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(4, 0, 1);
        t.put(8, 1, 0);
        t.put(2, 2, 0);
        t.put(8, 3, 0);
        t.put(2, 1, 1);
        t.put(4, 2, 1);
        t.put(2, 3, 1);
        t.put(2, 0, 2);
        t.put(8, 1, 2);
        t.put(2, 2, 2);
        t.put(8, 3, 2);
        t.put(4, 0, 3);
        t.put(2, 1, 3);
        t.put(4, 2, 3);
        t.put(2, 3, 3);
        assertTrue(t.isGameOver());
    }

    @Test
    public void testGameNotOver() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 0, 0);
        t.put(2, 0, 1);
        t.put(8, 1, 0);
        t.put(2, 2, 0);
        t.put(8, 3, 0);
        t.put(2, 1, 1);
        t.put(4, 2, 1);
        t.put(2, 3, 1);
        t.put(2, 0, 2);
        t.put(8, 1, 2);
        t.put(2, 2, 2);
        t.put(8, 3, 2);
        t.put(4, 0, 3);
        t.put(2, 1, 3);
        t.put(4, 2, 3);
        t.put(2, 3, 3);
        assertFalse(t.isGameOver());
    }

    @Test
    public void testUndo() {
        TwentyFortyEight t = new TwentyFortyEight();
        t.put(2, 3, 1);
        t.put(2, 0, 3);
        t.addBoard(t.getBoard());
        t.addScore(t.getScore());
        t.left();
        int[][] expected = {{0, 0, 0, 2},
                            {0, 0, 0, 0},
                            {0, 0, 0, 0},
                            {0, 2, 0, 0}};
        int expectedScore = 0;
        int[][] actual = t.previousBoard();
        int actualScore = t.getPreviousScore();
        assertArrayEquals(expected, actual);
        assertEquals(expectedScore, actualScore);
    }

}
