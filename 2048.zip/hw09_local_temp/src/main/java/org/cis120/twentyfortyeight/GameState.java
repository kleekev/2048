package org.cis120.twentyfortyeight;

public enum GameState {
    start,
    win,
    lose,
    running
}
